# Fear & Greed 통합 대시보드 실행법

## Windows PC (가장 쉬움)
1. ZIP 압축을 모두 풉니다.
2. https://www.python.org/downloads/ 에서 Python 3.11 이상을 설치합니다. 설치 때 **Add python.exe to PATH** 를 체크하세요.
3. 폴더 안의 `실행하기_Windows.bat`를 더블클릭합니다.
4. 필요한 라이브러리 설치가 끝나면 브라우저가 열립니다. 열리지 않으면 http://localhost:8501 로 들어가세요.
5. 왼쪽에서 미국 또는 한국 시장을 선택합니다. 미국은 Yahoo Finance 자동 조회가 되고, 한국은 기존 데이터 엑셀 파일을 업로드해야 합니다.
6. 시장 선택 메뉴에서 S&P500, NASDAQ, KOSPI, KOSDAQ 중 표시 대상을 고릅니다.
7. 대시보드에서 심리, 가격, 매매 신호, 백테스트, CSV 다운로드를 확인하세요.

## 명령어 실행 (macOS/Linux/Windows)
```
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## 사이트로 배포하기 (다른 기기에서도 접속)
GitHub 저장소에 `app.py`, `fear_greed_engine.py`, `requirements.txt`를 올리고 Streamlit Community Cloud에서 `app.py`를 지정해 배포하세요. 공개 저장소/앱에 투자 계좌 정보나 개인 원본 파일을 올리지 마세요. Yahoo Finance 접근이 서버에서 제한될 수 있습니다.

## 데이터 관련 주의
- 한국은 실시간 자동 연동이 아닙니다. 사용자가 업로드한 원본 엑셀의 마지막 날짜가 기준일입니다.
- 미국도 데이터 제공자와 시차로 최신 거래일이 다를 수 있습니다. 첫째 줄의 기준일을 확인하세요.
- 점수는 CNN의 공식 Fear & Greed Index가 아니라 사용자 정의 4~5개 지표 모델입니다.
- 미래 데이터 참조를 피하기 위해 252거래일 롤링 정규화를 사용합니다.
- 각 시장의 원본 특성이 달라 동일한 점수라도 절대적 의미가 같지는 않습니다.
- 거래 신호는 종가 기준 확정, 모의 거래 수익은 다음 거래일의 종가 대 종가 수익률로 계산됩니다. 실제 체결가를 재현하는 백테스트는 아닙니다.
